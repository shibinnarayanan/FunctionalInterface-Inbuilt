package com.svv;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerDemo {

	public static void main(String[] args) {
		List<String> cities = new ArrayList<>();
		cities.add("Delhi");
		cities.add("Mumbai");
		cities.add("Goa");
		cities.add("Pune");

		Consumer<String> printConsumer = city -> System.out.println(city);
		cities.forEach(printConsumer);
	}

}
