package com.svv;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		List<String> cities = new ArrayList<>();
		cities.add("Delhi");
		cities.add("Mumbai");
		cities.add("Goa");
		cities.add("Pune");

		Predicate<String> filterCity = city -> city.equals("Mumbai");
		cities.stream().filter(filterCity).forEach(System.out::println);
	}
}
