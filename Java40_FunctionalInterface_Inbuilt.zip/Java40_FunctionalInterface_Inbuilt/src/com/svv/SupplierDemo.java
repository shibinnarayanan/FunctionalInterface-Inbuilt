package com.svv;

import java.util.Arrays;
import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		Supplier<String[]> citySupplier = () -> {
			return new String[] { "Mumbai", "Delhi", "Goa", "Pune" };
		};
		Arrays.asList(citySupplier.get()).forEach(System.out::println);
	}
}
